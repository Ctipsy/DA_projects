#!/usr/bin/env python3
#遇到的编码字符流问题参考了如下博客的解决方案
#https://blog.csdn.net/zhangyunfei_happy/article/details/47169939
import jieba
import re
# jieba.load_userdict('userdict.txt')
# 创建停用词list
def stopwordslist(filepath):
    stopwords = [line.strip() for line in open(filepath, 'rb').readlines()]
    return stopwords

# 对句子进行分词
def seg_sentence(sentence):
    sentence_seged = jieba.cut(sentence.strip())
    stopwords = stopwordslist('stop_word.txt')  # 这里加载停用词的路径
    outstr = ''
    for word in sentence_seged:
        if word not in stopwords:
            if word != '\t':
                outstr += word
                outstr += " "
    return outstr

if __name__ == '__main__':
    txt = open('all','r',encoding='UTF-8').read()
    txt = re.sub("[A-Za-z0-9\[\`\~\!\@\#\$\^\&\*\(\)\=\|\{\}\'\:\;\'\,\[\]\.\<\>\/\?\~\！\@\#\\\&\*\%]", "", txt)
    inputs = open('all.txt', 'rb')
    outputs = open('all_outputs.txt', 'bw')
    for line in inputs:
        line_seg = seg_sentence(line).encode('utf-8')  # 这里的返回值是字符串
        outputs.write(line_seg)
        outputs.write('\n'.encode('utf-8'))
    outputs.close()
    inputs.close()
